
# PANAMÁ PRINT - Agente IA WhatsApp FORMA 2

## PASO A PASO PARA QUE EL MISMO META RESPONDA:

### 1. Crear App en Meta
- Ve a developers.facebook.com > Mis Apps > Crear App > Tipo: Negocio
- Nombre: Panama Print Bot

### 2. Agregar WhatsApp
- En el panel izquierdo: Agregar producto > WhatsApp > Configurar
- En API Setup copia:
  - PHONE_NUMBER_ID
  - Crea un token permanente en: Configuración > Tokens de acceso

### 3. Subir este código
- Sube estos archivos a Render.com (gratis):
  - Crea cuenta en render.com
  - New Web Service > Conecta este repo o sube ZIP
  - Build command: npm install
  - Start command: node app.js
  - Agrega variables de entorno de tu .env en Render > Environment

### 4. Configurar Webhook en Meta
- En WhatsApp > Configuración > Webhook
- URL: https://tu-app.onrender.com/webhook
- Verify Token: panama_print_123 (el mismo de tu .env)
- Suscribir a: messages

### 5. Probar
- Mándate un WhatsApp al número de prueba que te da Meta
- Debe responder automático

### 6. Pasar a número real
- En WhatsApp > API Setup > Agregar número de teléfono real
- Meta verifica tu negocio (1-2 días)

COSTO: Meta cobra $0.043 por conversación de 24h en Panamá (2026). Las primeras 1000 conversaciones/mes gratis.

SOPORTE: Si te trabas en un paso, mándame screenshot de donde quedaste y te digo qué poner.
